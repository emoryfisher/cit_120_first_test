document.body.querySelector("#cool").innerHTML="Hyia"

var prompter = prompt("Whst is your name");

document.body.querySelector("#lessCool").innerHTML=prompter;